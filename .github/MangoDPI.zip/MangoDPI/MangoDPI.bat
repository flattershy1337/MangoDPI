@echo off
chcp 1251 > nul
set "MANGO_VERSION=1.0.0"

cd /d "%~dp0"

:: ============================================================
:: ����� ����� � ������ ���� ��������������
:: ============================================================
if "%1"=="admin" (
    call :check_command chcp
    call :check_command find
    call :check_command findstr
    call :check_command netsh
    call :load_user_lists
    echo Started with admin rights
) else (
    call :check_extracted
    call :check_command powershell
    echo Requesting admin rights...
    powershell -NoProfile -Command "Start-Process 'cmd.exe' -ArgumentList '/c \"\"%~f0\" admin\"' -Verb RunAs"
    exit
)


:: ============================================================
:: ������� ����
:: ============================================================
setlocal EnableDelayedExpansion
:menu
cls
call :ipset_switch_status
call :game_switch_status
call :get_strategy_name

set "menu_choice=null"

rem ============================================================
:MENU
cls
echo.
echo   888b     d888                                      8888888b.  8888888b. 8888888
echo   8888b   d8888                                      888  "Y88b 888   Y88b  888
echo   88888b.d88888                                      888    888 888    888  888
echo   888Y88888P888  8888b.  88888b.   .d88b.   .d88b.  888    888 888   d88P  888
echo   888 Y888P 888     "88b 888 "88b d88P"88b d88""88b 888    888 8888888P"   888
echo   888  Y8P  888 .d888888 888  888 888  888 888  888 888    888 888         888
echo   888   "   888 888  888 888  888 Y88b 888 Y88..88P 888  .d88P 888         888
echo   888       888 "Y888888 888  888  "Y88888  "Y88P"  8888888P"  888       8888888
echo                                        888
echo                                   Y8b d88P        %MANGO_VERSION% 
echo                                    "Y88P"
echo.
echo  ================================================================
echo.
if defined CurrentStrategy (
    echo    ��������� : !CurrentStrategy!
) else (
    echo    ��������� : �� �����������
)
echo    IPSet     : [!IPsetStatus!]    ����: [!GameFilterStatus!]
echo.
echo   ============================================================
echo   :: ���������
echo      1. ������� ���������
echo      2. ������� ���������������� ���������
echo      3. ������� ���������������� ���������
echo.
echo   :: ������
echo      4. ���������� ������ (������� ���������)
echo      5. ������� ������
echo      6. ������ �������
echo.
echo   :: ���������
echo      7. ������� ������          [!GameFilterStatus!]
echo      8. IPSet ������            [!IPsetStatus!]
echo      9. ������� IP / TTL
echo.
echo   :: ������ �������
echo      10. ���������� list-general-user.txt
echo      11. ���������� list-exclude-user.txt
echo.
echo   :: ������������
echo      12. �������� IPSet ������
echo      13. �������� Hosts ����
echo      14. �����������
echo      15. �����
echo.
echo   ============================================================?
echo      0. �����
echo.

set /p menu_choice=   �������� ����� (0-15): 

if "%menu_choice%"=="1"  goto strategy_select
if "%menu_choice%"=="2"  goto strategy_create
if "%menu_choice%"=="3"  goto strategy_delete
if "%menu_choice%"=="4"  goto service_install
if "%menu_choice%"=="5"  goto service_remove
if "%menu_choice%"=="6"  goto service_status
if "%menu_choice%"=="7"  goto game_switch
if "%menu_choice%"=="8"  goto ipset_switch
if "%menu_choice%"=="9"  goto iphide_menu
if "%menu_choice%"=="10" goto list_general_user
if "%menu_choice%"=="11" goto list_exclude_user
if "%menu_choice%"=="12" goto ipset_update
if "%menu_choice%"=="13" goto hosts_update
if "%menu_choice%"=="14" goto service_diagnostics
if "%menu_choice%"=="15" goto run_tests
if "%menu_choice%"=="0"  exit /b
goto menu


:: ============================================================
:: ����� ���������
:: ============================================================
:strategy_select
cls
chcp 1251 > nul
echo.
echo  ����� ���������
echo  ============================================================
echo.
echo  [����������]
echo.
echo   1. general
echo      ����������� ���������. multisplit + fake QUIC.
echo      ������������� ��� ������ ������� ��� ����������� �����������.
echo.
echo   2. general ALT
echo      fake + fakedsplit, fooling=ts.
echo      ������������ general, ���� ����������� �� ��������.
echo.
echo   3. general ALT2
echo      multisplit � ������ seqovl (pos=2). ������� ��� �����������
echo      � ������������� ���������� TLS.
echo.
echo   4. general ALT3
echo      fake + hostfakesplit, fooling=ts, ����������� sni=www.google.com.
echo      ���������� ��� ��� ����� ������� SNI.
echo.
echo   5. general ALT4
echo      fake + multisplit + badseq. ����������� ����� �
echo      ����������� badseq-increment.
echo.
echo   6. SIMPLE FAKE
echo      ������ fake, fooling=ts, ��� multidisorder.
echo      ˸���� ��������� � ����������� ���������.
echo.
echo   7. SIMPLE FAKE ALT
echo      SIMPLE FAKE + stun.bin ��� �������������� fake-����.
echo.
echo   8. FAKE TLS AUTO
echo      fake + multidisorder � TLS-������������ (sni=www.google.com).
echo      ������ ������� ��� ����������� � �������� ���������� TLS.
echo.
echo   9. FAKE TLS AUTO ALT
echo      FAKE TLS AUTO + fakedsplit + badseq. ����������� �����������
echo      ����� � ������������ TLS.
echo.

echo  [����������������]
set "custom_count=0"
if exist "%~dp0utils\strategies\" (
    for %%F in ("%~dp0utils\strategies\*.cfg") do (
        set /a custom_count+=1
        set "cfile!custom_count!=%%~nF"
        set "cdesc!custom_count!=%%~nF"
        for /f "usebackq tokens=2 delims==" %%V in (`findstr /i "^description=" "%%F" 2^>nul`) do set "cdesc!custom_count!=%%V"
        set "cnum=!custom_count!"
        set /a "cnum+=9"
        call set "_cf=%%cfile!custom_count!%%"
        call set "_cd=%%cdesc!custom_count!%%"
        echo   !cnum!. !_cf! � !_cd!
    )
)
if !custom_count!==0 echo   (��� ���������������� ���������)
echo.
echo   0. �����
echo.

set "schoice="
set /p "schoice=  �������� ���������: "
if "%schoice%"==""  goto menu
if "%schoice%"=="0" goto menu
if "%schoice%"=="1" ( set "SELECTED_STRATEGY=general"           & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="2" ( set "SELECTED_STRATEGY=general_alt"       & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="3" ( set "SELECTED_STRATEGY=general_alt2"      & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="4" ( set "SELECTED_STRATEGY=general_alt3"      & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="5" ( set "SELECTED_STRATEGY=general_alt4"      & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="6" ( set "SELECTED_STRATEGY=simple_fake"       & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="7" ( set "SELECTED_STRATEGY=simple_fake_alt"   & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="8" ( set "SELECTED_STRATEGY=fake_tls_auto"     & set "SELECTED_TYPE=builtin" & goto strategy_apply )
if "%schoice%"=="9" ( set "SELECTED_STRATEGY=fake_tls_auto_alt" & set "SELECTED_TYPE=builtin" & goto strategy_apply )

:: ���������������� ���������
for /l %%i in (1,1,%custom_count%) do (
    set /a "cnum=%%i+9"
    if "!schoice!"=="!cnum!" (
        set "SELECTED_STRATEGY=!cfile%%i!"
        set "SELECTED_TYPE=custom"
        goto strategy_apply
    )
)
goto strategy_select

:strategy_apply
echo !SELECTED_STRATEGY!> "%~dp0utils\current_strategy.txt"
echo !SELECTED_TYPE!>> "%~dp0utils\current_strategy.txt"
call :PrintGreen "��������� '!SELECTED_STRATEGY!' �������."
call :PrintYellow "�������������� ������ (����� 4) ����� ���������."
pause
goto menu


:: ============================================================
:: �������� ���������������� ���������
:: ============================================================
:strategy_create
cls
chcp 1251 > nul
echo.
echo  �������� ���������������� ���������
echo  ============================================================
echo.

set "cs_name="
set /p "cs_name=  �������� ��������� (��������, ��� ��������): "
if "%cs_name%"=="" goto menu

if exist "%~dp0utils\strategies\%cs_name%.cfg" (
    call :PrintYellow "��������� � ����� ������ ��� ����������."
    pause
    goto menu
)

echo.
echo  ������ (������� ���������):
echo    1. general
echo    2. general ALT
echo    3. SIMPLE FAKE
echo    4. FAKE TLS AUTO
echo    5. FAKE TLS AUTO ALT
echo.
set "cs_tpl=1"
set /p "cs_tpl=  ������ [1-5, default: 1]: "
if "%cs_tpl%"=="" set "cs_tpl=1"

echo.
echo  ����� DPI-��������������� (--dpi-desync):
echo    1. fake
echo    2. multisplit
echo    3. fake,multisplit
echo    4. multidisorder
echo    5. fake,multidisorder
echo    6. fakedsplit
echo    7. fake,fakedsplit
echo    8. hostfakesplit
echo    9. ������ �������
echo.
set "cs_dsync_choice=1"
set /p "cs_dsync_choice=  ����� [1-9, default: 1]: "
if "%cs_dsync_choice%"=="" set "cs_dsync_choice=1"
if "%cs_dsync_choice%"=="1" set "cs_dsync=fake"
if "%cs_dsync_choice%"=="2" set "cs_dsync=multisplit"
if "%cs_dsync_choice%"=="3" set "cs_dsync=fake,multisplit"
if "%cs_dsync_choice%"=="4" set "cs_dsync=multidisorder"
if "%cs_dsync_choice%"=="5" set "cs_dsync=fake,multidisorder"
if "%cs_dsync_choice%"=="6" set "cs_dsync=fakedsplit"
if "%cs_dsync_choice%"=="7" set "cs_dsync=fake,fakedsplit"
if "%cs_dsync_choice%"=="8" set "cs_dsync=hostfakesplit"
if "%cs_dsync_choice%"=="9" (
    set "cs_dsync="
    set /p "cs_dsync=  ������� �������� --dpi-desync=: "
)

echo.
set "cs_repeats=6"
set /p "cs_repeats=  ������ fake-������� (--dpi-desync-repeats) [default: 6]: "
if "%cs_repeats%"=="" set "cs_repeats=6"

echo.
echo  Fool-����� (--dpi-desync-fooling):
echo    1. none (�� ������������)
echo    2. ts
echo    3. badseq
echo    4. md5sig
echo    5. ts,md5sig
echo    6. ������ �������
echo.
set "cs_fool_choice=1"
set /p "cs_fool_choice=  Fool [1-6, default: 1]: "
if "%cs_fool_choice%"=="" set "cs_fool_choice=1"
if "%cs_fool_choice%"=="1" set "cs_fool="
if "%cs_fool_choice%"=="2" set "cs_fool=ts"
if "%cs_fool_choice%"=="3" set "cs_fool=badseq"
if "%cs_fool_choice%"=="4" set "cs_fool=md5sig"
if "%cs_fool_choice%"=="5" set "cs_fool=ts,md5sig"
if "%cs_fool_choice%"=="6" (
    set "cs_fool="
    set /p "cs_fool=  ������� �������� --dpi-desync-fooling=: "
)

echo.
set "cs_tcp=80,443,2053,2083,2087,2096,8443"
set /p "cs_tcp=  TCP ����� [default: 80,443,2053,2083,2087,2096,8443]: "
if "%cs_tcp%"=="" set "cs_tcp=80,443,2053,2083,2087,2096,8443"

set "cs_udp=443,19294-19344,50000-50100"
set /p "cs_udp=  UDP ����� [default: 443,19294-19344,50000-50100]: "
if "%cs_udp%"=="" set "cs_udp=443,19294-19344,50000-50100"

echo.
echo  ������� ������:
echo    1. ���
echo    2. TCP � UDP
echo    3. ������ TCP
echo    4. ������ UDP
echo.
set "cs_game=1"
set /p "cs_game=  [1-4, default: 1]: "
if "%cs_game%"=="" set "cs_game=1"

echo.
set "cs_google=N"
set /p "cs_google=  �������� Google IP-������ (list-google.txt)? [Y/N, default: N]: "
if /i "%cs_google%"=="" set "cs_google=N"

set "cs_discord=N"
set /p "cs_discord=  �������� Discord-������ (discord.media)? [Y/N, default: N]: "
if /i "%cs_discord%"=="" set "cs_discord=N"

echo.
set "cs_domains="
set /p "cs_domains=  �������������� ������ ����� ������� (��� Enter ����� ����������): "

echo.
set "cs_desc=%cs_name% (custom)"
set /p "cs_desc=  �������� ��������� [default: %cs_name% (custom)]: "
if "%cs_desc%"=="" set "cs_desc=%cs_name% (custom)"

:: ��������� .cfg
if not exist "%~dp0utils\strategies\" mkdir "%~dp0utils\strategies\"
(
    echo description=%cs_desc%
    echo template=%cs_tpl%
    echo dpi_desync=%cs_dsync%
    echo dpi_repeats=%cs_repeats%
    echo fooling=%cs_fool%
    echo tcp_ports=%cs_tcp%
    echo udp_ports=%cs_udp%
    echo game_filter=%cs_game%
    echo google_filter=%cs_google%
    echo discord_filter=%cs_discord%
    echo extra_domains=%cs_domains%
) > "%~dp0utils\strategies\%cs_name%.cfg"

call :PrintGreen "��������� '%cs_name%' �������."
call :PrintYellow "�������� � � ������ 1, ����� ���������� ������ (����� 4)."
pause
goto menu


:: ============================================================
:: �������� ���������������� ���������
:: ============================================================
:strategy_delete
cls
chcp 1251 > nul
echo.
echo  �������� ���������������� ���������
echo  ============================================================
echo.

set "del_count=0"
if exist "%~dp0utils\strategies\" (
    for %%F in ("%~dp0utils\strategies\*.cfg") do (
        set /a del_count+=1
        set "delfile!del_count!=%%~nF"
        echo   !del_count!. %%~nF
    )
)
if !del_count!==0 (
    echo   ��� ���������������� ���������.
    pause
    goto menu
)
echo   0. �����
echo.
set "dchoice="
set /p "dchoice=  ������� ����� ��� ��������: "
if "%dchoice%"=="" goto menu
if "%dchoice%"=="0" goto menu

for /l %%i in (1,1,%del_count%) do (
    if "!dchoice!"=="%%i" (
        del /f /q "%~dp0utils\strategies\!delfile%%i!.cfg"
        call :PrintGreen "��������� '!delfile%%i!' �������."
        pause
        goto menu
    )
)
goto strategy_delete


:: ============================================================
:: ��������� �������
:: ============================================================
:service_install
cls
chcp 1251 > nul

set "BIN_PATH=%~dp0bin\"
set "LISTS_PATH=%~dp0lists\"

:: ��������� ������� ���������
set "SI_STRATEGY=general"
set "SI_TYPE=builtin"
if exist "%~dp0utils\current_strategy.txt" (
    set "lnum=0"
    for /f "usebackq delims=" %%A in ("%~dp0utils\current_strategy.txt") do (
        set /a lnum+=1
        if !lnum!==1 set "SI_STRATEGY=%%A"
        if !lnum!==2 set "SI_TYPE=%%A"
    )
)

call :game_switch_status
call :load_user_lists

:: ��������� ��������� ������� IP
set "IPHIDE_IPID="
set "IPHIDE_TTL="
if exist "%~dp0utils\ip_hide.cfg" (
    for /f "usebackq tokens=1,2 delims==" %%A in ("%~dp0utils\ip_hide.cfg") do (
        if "%%A"=="ip_id_zero" if "%%B"=="1" set "IPHIDE_IPID=--ip-id=zero"
        if "%%A"=="ttl_value"  if not "%%B"==""  set "IPHIDE_TTL=--dpi-desync-ttl=%%B"
    )
)

if "!SI_TYPE!"=="custom" (
    call :build_custom_args "!SI_STRATEGY!"
    set "FINAL_ARGS=!CUSTOM_ARGS!"
) else (
    call :build_builtin_args "!SI_STRATEGY!"
    set "FINAL_ARGS=!BUILTIN_ARGS!"
)

call :tcp_enable

if not "!IPHIDE_IPID!"=="" set "FINAL_ARGS=!FINAL_ARGS! !IPHIDE_IPID!"
if not "!IPHIDE_TTL!"=="" set "FINAL_ARGS=!FINAL_ARGS! !IPHIDE_TTL!"
set SRVCNAME=zapret
net stop %SRVCNAME% >nul 2>&1
sc delete %SRVCNAME% >nul 2>&1
sc create %SRVCNAME% binPath= "\"%BIN_PATH%winws.exe\" !FINAL_ARGS!" DisplayName= "zapret" start= auto
sc description %SRVCNAME% "MangoDPI bypass"
sc start %SRVCNAME%
reg add "HKLM\System\CurrentControlSet\Services\zapret" /v zapret-discord-youtube /t REG_SZ /d "!SI_STRATEGY!" /f

echo.
call :PrintGreen "������ ���������� �� ����������: !SI_STRATEGY!"
pause
goto menu


:: ============================================================
:: ���������� ���������� � ���������� ���������
:: ��� ���� ���������� ���������� BIN_PATH � LISTS_PATH
:: ============================================================
:build_builtin_args
set "STRAT=%~1"
set "BIN=%BIN_PATH%"
set "LISTS=%LISTS_PATH%"
set "BUILTIN_ARGS="

:: --- general ---
if "!STRAT!"=="general" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=multisplit --dpi-desync-split-seqovl=681 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=multisplit --dpi-desync-split-seqovl=568 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_4pda_to.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=multisplit --dpi-desync-split-seqovl=568 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_4pda_to.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=multisplit --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n3 --dpi-desync-split-seqovl=568 --dpi-desync-split-pos=1 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_4pda_to.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=12 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n2"
goto :eof
)

:: --- general ALT (fake+fakedsplit, fooling=ts) ---
if "!STRAT!"=="general_alt" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,fakedsplit --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-fooling=ts --dpi-desync-fakedsplit-pattern=0x00 --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=12 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n3"
goto :eof
)

:: --- general ALT2 (multisplit seqovl=652, pos=2) ---
if "!STRAT!"=="general_alt2" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=multisplit --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=multisplit --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n3 --dpi-desync-split-seqovl=652 --dpi-desync-split-pos=2 --dpi-desync-split-seqovl-pattern=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=12 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n2"
goto :eof
)

:: --- general ALT3 (fake+hostfakesplit, sni=google) ---
if "!STRAT!"=="general_alt3" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,hostfakesplit --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-hostfakesplit-mod=host=www.google.com,altorder=1 --dpi-desync-fooling=ts --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake,hostfakesplit --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-hostfakesplit-mod=host=www.google.com,altorder=1 --dpi-desync-fooling=ts --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,hostfakesplit --dpi-desync-fake-tls-mod=rnd,dupsid,sni=ya.ru --dpi-desync-hostfakesplit-mod=host=ya.ru,altorder=1 --dpi-desync-fooling=ts --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,hostfakesplit --dpi-desync-fake-tls-mod=rnd,dupsid,sni=ya.ru --dpi-desync-hostfakesplit-mod=host=ya.ru,altorder=1 --dpi-desync-fooling=ts --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,hostfakesplit --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=ya.ru --dpi-desync-hostfakesplit-mod=host=ya.ru,altorder=1 --dpi-desync-fooling=ts --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=10 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n4"
goto :eof
)

:: --- general ALT4 (fake+multisplit+badseq) ---
if "!STRAT!"=="general_alt4" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multisplit --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=1000 --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake,multisplit --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=1000 --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,multisplit --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=1000 --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,multisplit --dpi-desync-repeats=6 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=1000 --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,multisplit --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n3 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=1000 --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=10 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n2"
goto :eof
)

:: --- SIMPLE FAKE (������ fake, fooling=ts) ---
if "!STRAT!"=="simple_fake" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=12 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n3"
goto :eof
)

:: --- SIMPLE FAKE ALT (+ stun.bin + max_ru) ---
if "!STRAT!"=="simple_fake_alt" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!tls_clienthello_www_google_com.bin\" --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_max_ru.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_max_ru.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=6 --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-fooling=ts --dpi-desync-fake-tls=\"!BIN!stun.bin\" --dpi-desync-fake-tls=\"!BIN!tls_clienthello_max_ru.bin\" --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=12 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n3"
goto :eof
)

:: --- FAKE TLS AUTO (fake+multidisorder, sni=www.google.com) ---
if "!STRAT!"=="fake_tls_auto" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=0x00000000 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=0x00000000 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=0x00000000 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,multidisorder --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=0x00000000 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,multidisorder --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-split-pos=1,midsld --dpi-desync-repeats=11 --dpi-desync-fooling=badseq --dpi-desync-fake-tls=0x00000000 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=10 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n2"
goto :eof
)

:: --- FAKE TLS AUTO ALT (+ fakedsplit + badseq) ---
if "!STRAT!"=="fake_tls_auto_alt" (
set "BUILTIN_ARGS=--wf-tcp=80,443,2053,2083,2087,2096,8443,!GameFilterTCP! --wf-udp=443,19294-19344,50000-50100,!GameFilterUDP! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-udp=19294-19344,50000-50100 --filter-l7=discord,stun --dpi-desync=fake --dpi-desync-fake-discord=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-fake-stun=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-repeats=6 --new --filter-tcp=2053,2083,2087,2096,8443 --hostlist-domains=discord.media --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --dpi-desync-repeats=8 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --new --filter-tcp=443 --hostlist=\"!LISTS!list-google.txt\" !IPHIDE_IPID! --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --dpi-desync-repeats=8 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --new --filter-tcp=80,443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --dpi-desync-repeats=8 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=11 --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\" --new --filter-tcp=80,443,8443 --ipset=\"!LISTS!ipset-all.txt\" --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,fakedsplit --dpi-desync-split-pos=1 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --dpi-desync-repeats=8 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-tcp=!GameFilterTCP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake,fakedsplit --dpi-desync-any-protocol=1 --dpi-desync-cutoff=n4 --dpi-desync-split-pos=1 --dpi-desync-fooling=badseq --dpi-desync-badseq-increment=2 --dpi-desync-repeats=8 --dpi-desync-fake-tls-mod=rnd,dupsid,sni=www.google.com --dpi-desync-fake-http=\"!BIN!tls_clienthello_max_ru.bin\" --new --filter-udp=!GameFilterUDP! --ipset=\"!LISTS!ipset-all.txt\" --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\" --dpi-desync=fake --dpi-desync-repeats=10 --dpi-desync-any-protocol=1 --dpi-desync-fake-unknown-udp=\"!BIN!quic_initial_dbankcloud_ru.bin\" --dpi-desync-cutoff=n2"
goto :eof
)

goto :eof


:: ============================================================
:: ���������� ���������� � ���������������� ���������
:: ============================================================
:build_custom_args
set "CNAME=%~1"
set "CFGFILE=%~dp0utils\strategies\%CNAME%.cfg"
set "CUSTOM_ARGS="

if not exist "!CFGFILE!" (
    call :PrintRed "���� ��������� �� ������: !CFGFILE!"
    goto :eof
)

:: ������ ��������� �� .cfg
set "c_tpl=1"
set "c_dsync=fake"
set "c_repeats=6"
set "c_fool="
set "c_tcp=80,443,2053,2083,2087,2096,8443"
set "c_udp=443,19294-19344,50000-50100"
set "c_game=1"
set "c_google=N"
set "c_discord=N"
set "c_domains="

for /f "usebackq tokens=1,2 delims==" %%A in ("!CFGFILE!") do (
    if "%%A"=="template"       set "c_tpl=%%B"
    if "%%A"=="dpi_desync"     set "c_dsync=%%B"
    if "%%A"=="dpi_repeats"    set "c_repeats=%%B"
    if "%%A"=="fooling"        set "c_fool=%%B"
    if "%%A"=="tcp_ports"      set "c_tcp=%%B"
    if "%%A"=="udp_ports"      set "c_udp=%%B"
    if "%%A"=="game_filter"    set "c_game=%%B"
    if "%%A"=="google_filter"  set "c_google=%%B"
    if "%%A"=="discord_filter" set "c_discord=%%B"
    if "%%A"=="extra_domains"  set "c_domains=%%B"
)

:: ������ fool-��������
set "c_fool_param="
if not "!c_fool!"=="" set "c_fool_param=--dpi-desync-fooling=!c_fool!"

:: ������ hostlist ��� extra_domains
set "c_extra_hl="
if not "!c_domains!"=="" (
    for %%D in (!c_domains!) do (
        set "c_extra_hl=!c_extra_hl! --hostlist-domains=%%D"
    )
)

:: Google filter
set "c_google_filter="
if /i "!c_google!"=="Y" set "c_google_filter=--hostlist=\"%LISTS_PATH%list-google.txt\" !IPHIDE_IPID!"

:: Discord filter
set "c_discord_filter="
if /i "!c_discord!"=="Y" set "c_discord_filter=--hostlist-domains=discord.media"

:: Game ports
set "c_gtcp=12"
set "c_gudp=12"
if "!c_game!"=="2" ( set "c_gtcp=1024-65535" & set "c_gudp=1024-65535" )
if "!c_game!"=="3" ( set "c_gtcp=1024-65535" )
if "!c_game!"=="4" ( set "c_gudp=1024-65535" )

set "BIN=%BIN_PATH%"
set "LISTS=%LISTS_PATH%"

set "CUSTOM_ARGS=--wf-tcp=!c_tcp!,!c_gtcp! --wf-udp=!c_udp!,!c_gudp!"
set "CUSTOM_ARGS=!CUSTOM_ARGS! --filter-udp=443 --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\"!c_extra_hl!"
set "CUSTOM_ARGS=!CUSTOM_ARGS! --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\""
set "CUSTOM_ARGS=!CUSTOM_ARGS! --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\""
set "CUSTOM_ARGS=!CUSTOM_ARGS! --dpi-desync=!c_dsync! --dpi-desync-repeats=!c_repeats! !c_fool_param!"
set "CUSTOM_ARGS=!CUSTOM_ARGS! --dpi-desync-fake-quic=\"!BIN!quic_initial_www_google_com.bin\""
if not "!c_google_filter!"=="" (
    set "CUSTOM_ARGS=!CUSTOM_ARGS! --new --filter-tcp=443 !c_google_filter! --dpi-desync=!c_dsync! --dpi-desync-repeats=!c_repeats! !c_fool_param!"
)
if not "!c_discord_filter!"=="" (
    set "CUSTOM_ARGS=!CUSTOM_ARGS! --new --filter-tcp=2053,2083,2087,2096,8443 !c_discord_filter! --dpi-desync=!c_dsync! --dpi-desync-repeats=!c_repeats! !c_fool_param!"
)
set "CUSTOM_ARGS=!CUSTOM_ARGS! --new --filter-tcp=80,443"
set "CUSTOM_ARGS=!CUSTOM_ARGS! --hostlist=\"!LISTS!list-general.txt\" --hostlist=\"!LISTS!list-general-user.txt\"!c_extra_hl!"
set "CUSTOM_ARGS=!CUSTOM_ARGS! --hostlist-exclude=\"!LISTS!list-exclude.txt\" --hostlist-exclude=\"!LISTS!list-exclude-user.txt\""
set "CUSTOM_ARGS=!CUSTOM_ARGS! --ipset-exclude=\"!LISTS!ipset-exclude.txt\" --ipset-exclude=\"!LISTS!ipset-exclude-user.txt\""
set "CUSTOM_ARGS=!CUSTOM_ARGS! --dpi-desync=!c_dsync! --dpi-desync-repeats=!c_repeats! !c_fool_param!"
goto :eof


:: ============================================================
:: �������� �������
:: ============================================================
:service_remove
cls
chcp 1251 > nul
set SRVCNAME=zapret
sc query "!SRVCNAME!" >nul 2>&1
if !errorlevel!==0 (
    net stop %SRVCNAME%
    sc delete %SRVCNAME%
    call :PrintGreen "������ �����."
) else (
    echo ������ "%SRVCNAME%" �� ����������.
)
pause
goto menu


:: ============================================================
:: ������ �������
:: ============================================================
:service_status
cls
chcp 1251 > nul
sc query "zapret" >nul 2>&1
if !errorlevel!==0 (
    for /f "tokens=2*" %%A in ('reg query "HKLM\System\CurrentControlSet\Services\zapret" /v zapret-discord-youtube 2^>nul') do echo ����������� ���������: "%%B"
)
call :test_service zapret
call :test_service WinDivert
set "BIN_PATH_TMP=%~dp0bin\"
if not exist "%BIN_PATH_TMP%*.sys" (
    call :PrintRed "WinDivert64.sys NOT found."
)
echo:
tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if !errorlevel!==0 (
    call :PrintGreen "Bypass (winws.exe) �������."
) else (
    call :PrintRed "Bypass (winws.exe) �� �������."
)
pause
goto menu


:: ============================================================
:: ������� IP / TTL
:: ============================================================
:iphide_menu
cls
chcp 1251 > nul

set "IH_IPID=0"
set "IH_TTL="
if exist "%~dp0utils\ip_hide.cfg" (
    for /f "usebackq tokens=1,2 delims==" %%A in ("%~dp0utils\ip_hide.cfg") do (
        if "%%A"=="ip_id_zero" set "IH_IPID=%%B"
        if "%%A"=="ttl_value"  set "IH_TTL=%%B"
    )
)

set "IH_TTL_DISP=����"
if not "!IH_TTL!"=="" set "IH_TTL_DISP=!IH_TTL!"

echo.
echo  ������� IP (����������� ������ ����� ���������)
echo  ============================================================?
echo.
echo   1. IP-ID Zero     � --ip-id=zero � TCP 443 (Google-������)
echo      ������: !IH_IPID!   (0=����, 1=���)
echo.
echo   2. TTL �����      � --dpi-desync-ttl=N
echo      ������� ��������: !IH_TTL_DISP!
echo      (������ = ���������)
echo.
echo   0. �����
echo.
set "ih_choice="
set /p "ih_choice=  �������� ��������: "
if "%ih_choice%"=="0" goto menu

if "%ih_choice%"=="1" (
    if "!IH_IPID!"=="1" ( set "IH_IPID=0" ) else ( set "IH_IPID=1" )
)
if "%ih_choice%"=="2" (
    set "IH_TTL_NEW="
    set /p "IH_TTL_NEW=  ������� �������� TTL (1-255, ��� Enter ����� ���������): "
    set "IH_TTL=!IH_TTL_NEW!"
)

(
    echo ip_id_zero=!IH_IPID!
    echo ttl_value=!IH_TTL!
) > "%~dp0utils\ip_hide.cfg"

call :PrintGreen "��������� ������� IP ���������."
call :PrintYellow "�������������� ������ (����� 4) ��� ����������."
pause
goto iphide_menu


:: ============================================================
:: ���������� list-general-user.txt
:: ============================================================
:list_general_user
cls
chcp 1251 > nul
set "LISTFILE=%~dp0lists\list-general-user.txt"
call :list_manager "!LISTFILE!" "list-general-user.txt (����������� ������)"
goto menu


:: ============================================================
:: ���������� list-exclude-user.txt
:: ============================================================
:list_exclude_user
cls
chcp 1251 > nul
set "LISTFILE=%~dp0lists\list-exclude-user.txt"
call :list_manager "!LISTFILE!" "list-exclude-user.txt (������-����������)"
goto menu


:: ������������� �������� ���������� ������
:list_manager
set "LM_FILE=%~1"
set "LM_TITLE=%~2"

if not exist "!LM_FILE!" echo domain.example.abc>"!LM_FILE!"

:lm_loop
cls
chcp 1251 > nul
echo.
echo  ����������: !LM_TITLE!
echo  ============================================================
echo.

set "lm_count=0"
for /f "usebackq delims=" %%L in ("!LM_FILE!") do (
    set /a lm_count+=1
    set "lm_line!lm_count!=%%L"
    echo   !lm_count!. %%L
)
echo.
echo   A. �������� �����
echo   D. ������� ����� (�� ������)
echo   C. �������� ������
echo   0. �����
echo.
set "lm_choice="
set /p "lm_choice=  ��������: "

if /i "!lm_choice!"=="0" goto :eof
if /i "!lm_choice!"=="A" (
    set "lm_new="
    set /p "lm_new=  ������� �����: "
    if not "!lm_new!"=="" (
        echo !lm_new!>>"!LM_FILE!"
        call :PrintGreen "���������: !lm_new!"
        timeout /t 1 /nobreak >nul
    )
    goto lm_loop
)
if /i "!lm_choice!"=="D" (
    set "lm_del="
    set /p "lm_del=  ������� ����� ��� ��������: "
    if not "!lm_del!"=="" (
        set "lm_del_line=!lm_line%lm_del%!"
        if defined lm_del_line (
            type "!LM_FILE!" | findstr /v /x "!lm_del_line!" > "%~dp0utils\lm_tmp.txt"
            move /y "%~dp0utils\lm_tmp.txt" "!LM_FILE!" >nul
            call :PrintGreen "�������: !lm_del_line!"
            timeout /t 1 /nobreak >nul
        )
    )
    goto lm_loop
)
if /i "!lm_choice!"=="C" (
    echo domain.example.abc>"!LM_FILE!"
    call :PrintYellow "������ ������."
    timeout /t 1 /nobreak >nul
    goto lm_loop
)
goto lm_loop


:: ============================================================
:: ���������� IPSET
:: ============================================================
:ipset_update
cls
chcp 1251 > nul
set "listFile=%~dp0lists\ipset-all.txt"
set "url=https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/refs/heads/main/.service/ipset-service.txt"
echo ���������� ipset-all...
if exist "%SystemRoot%\System32\curl.exe" (
    curl --version | find "libcurl/7"
    if !errorlevel!==0 (
        curl --ssl-no-revoke -L -o "!listFile!" "!url!"
    ) else (
        curl --ssl-revoke-best-effort -L -o "!listFile!" "!url!"
    )
) else (
    powershell -NoProfile -Command "$url='!url!';$out='!listFile!';$res=Invoke-WebRequest -Uri $url -TimeoutSec 10 -UseBasicParsing;if($res.StatusCode -eq 200){$res.Content|Out-File -FilePath $out -Encoding UTF8}else{exit 1}"
)
echo ������.
pause
goto menu


:: ============================================================
:: ���������� HOSTS
:: ============================================================
:hosts_update
cls
chcp 1251 > nul
set "hostsFile=%SystemRoot%\System32\drivers\etc\hosts"
set "hostsUrl=https://raw.githubusercontent.com/Flowseal/zapret-discord-youtube/refs/heads/main/.service/hosts"
set "tempFile=%TEMP%\mangodpi_hosts.txt"
set "needsUpdate=0"
echo �������� hosts �����...
if exist "%SystemRoot%\System32\curl.exe" (
    curl -L -s -o "!tempFile!" "!hostsUrl!"
) else (
    powershell -NoProfile -Command "$url='!hostsUrl!';$out='!tempFile!';$res=Invoke-WebRequest -Uri $url -TimeoutSec 10 -UseBasicParsing;if($res.StatusCode -eq 200){$res.Content|Out-File -FilePath $out -Encoding UTF8}else{exit 1}"
)
if not exist "!tempFile!" (
    call :PrintRed "�� ������� ��������� hosts ����."
    pause
    goto menu
)
set "firstLine="
set "lastLine="
for /f "usebackq delims=" %%a in ("!tempFile!") do (
    if not defined firstLine set "firstLine=%%a"
    set "lastLine=%%a"
)
findstr /C:"!firstLine!" "!hostsFile!" >nul 2>&1
if !errorlevel! neq 0 set "needsUpdate=1"
findstr /C:"!lastLine!" "!hostsFile!" >nul 2>&1
if !errorlevel! neq 0 set "needsUpdate=1"
if "!needsUpdate!"=="1" (
    call :PrintYellow "Hosts ���� ������� ����������."
    call :PrintYellow "���������� ���������� ��������� ����� � ��� hosts."
    start notepad "!tempFile!"
    explorer /select,"!hostsFile!"
) else (
    call :PrintGreen "Hosts ���� ��������."
    if exist "!tempFile!" del /f /q "!tempFile!"
)
pause
goto menu


:: ============================================================
:: �����������
:: ============================================================
:service_diagnostics
cls
chcp 1251 > nul
sc query BFE | findstr /I "RUNNING" > nul
if !errorlevel!==0 ( call :PrintGreen "Base Filtering Engine: OK" ) else ( call :PrintRed "[X] Base Filtering Engine �� �������!" )
echo:
set "proxyEnabled=0"
for /f "tokens=2*" %%A in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Internet Settings" /v ProxyEnable 2^>nul ^| findstr /i "ProxyEnable"') do if "%%B"=="0x1" set "proxyEnabled=1"
if !proxyEnabled!==1 ( call :PrintYellow "[?] ��������� ������ ������� � ����� ������" ) else ( call :PrintGreen "������: OK" )
echo:
netsh interface tcp show global | findstr /i "timestamps" | findstr /i "enabled" > nul
if !errorlevel!==0 ( call :PrintGreen "TCP Timestamps: OK" ) else (
    call :PrintYellow "[?] TCP timestamps ���������, �������..."
    netsh interface tcp set global timestamps=enabled > nul 2>&1
)
echo:
tasklist /FI "IMAGENAME eq AdguardSvc.exe" | find /I "AdguardSvc.exe" > nul
if !errorlevel!==0 ( call :PrintRed "[X] Adguard ������ � ����� ������������� � Discord" ) else ( call :PrintGreen "Adguard: OK" )
echo:
sc query | findstr /I "Killer" > nul
if !errorlevel!==0 ( call :PrintRed "[X] Killer services ������� � ����������� � zapret" ) else ( call :PrintGreen "Killer: OK" )
echo:
sc query | findstr /I "Intel" | findstr /I "Connectivity" > nul
if !errorlevel!==0 ( call :PrintRed "[X] Intel Connectivity Network Service � �������� � zapret" ) else ( call :PrintGreen "Intel Connectivity: OK" )
echo:
sc query | findstr /I "SmartByte" > nul
if !errorlevel!==0 ( call :PrintRed "[X] SmartByte ������ � �������� � zapret" ) else ( call :PrintGreen "SmartByte: OK" )
echo:
set "BIN_PATH_DIAG=%~dp0bin\"
if not exist "!BIN_PATH_DIAG!*.sys" ( call :PrintRed "WinDivert64.sys NOT found." ) else ( call :PrintGreen "WinDivert64.sys: OK" )
echo:
tasklist /FI "IMAGENAME eq winws.exe" | find /I "winws.exe" > nul
if !errorlevel!==0 ( call :PrintGreen "winws.exe: �������" ) else ( call :PrintRed "winws.exe: �� �������" )
echo:
set "conflicting_services=GoodbyeDPI discordfix_zapret winws1 winws2"
set "found_any_conflict=0"
set "found_conflicts="
for %%s in (!conflicting_services!) do (
    sc query "%%s" >nul 2>&1
    if !errorlevel!==0 (
        if "!found_conflicts!"=="" ( set "found_conflicts=%%s" ) else ( set "found_conflicts=!found_conflicts! %%s" )
        set "found_any_conflict=1"
    )
)
if !found_any_conflict!==1 (
    call :PrintRed "[X] ������������� �������: !found_conflicts!"
    set "CHOICE="
    set /p "CHOICE=������� �������������? (Y/N, default: N): "
    if "!CHOICE!"=="" set "CHOICE=N"
    if /i "!CHOICE!"=="Y" (
        for %%s in (!found_conflicts!) do (
            net stop "%%s" >nul 2>&1
            sc delete "%%s" >nul 2>&1
        )
        net stop "WinDivert" >nul 2>&1 & sc delete "WinDivert" >nul 2>&1
        net stop "WinDivert14" >nul 2>&1 & sc delete "WinDivert14" >nul 2>&1
    )
) else ( call :PrintGreen "���������: �� ����������" )
echo:
set "CHOICE="
set /p "CHOICE=�������� ��� Discord? (Y/N, default: Y): "
if "!CHOICE!"=="" set "CHOICE=Y"
if /i "!CHOICE!"=="Y" (
    tasklist /FI "IMAGENAME eq Discord.exe" | findstr /I "Discord.exe" > nul
    if !errorlevel!==0 ( taskkill /IM Discord.exe /F > nul )
    set "discordCacheDir=%appdata%\discord"
    for %%d in ("Cache" "Code Cache" "GPUCache") do (
        set "dirPath=!discordCacheDir!\%%~d"
        if exist "!dirPath!" rd /s /q "!dirPath!" >nul 2>&1
    )
    call :PrintGreen "��� Discord ������."
)
pause
goto menu


:: ============================================================
:: �����
:: ============================================================
:run_tests
cls
powershell -NoProfile -Command "if($PSVersionTable.PSVersion.Major -ge 3){exit 0}else{exit 1}" >nul 2>&1
if %errorLevel% neq 0 (
    echo PowerShell 3.0+ ����������.
    pause
    goto menu
)
echo ������ ������ � PowerShell...
start "" powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0utils\test zapret.ps1"
pause
goto menu


:: ============================================================
:: GAME SWITCH
:: ============================================================
:game_switch_status
chcp 1251 > nul
set "gameFlagFile=%~dp0utils\game_filter.enabled"
if not exist "!gameFlagFile!" (
    set "GameFilterStatus=disabled"
    set "GameFilter=12"
    set "GameFilterTCP=12"
    set "GameFilterUDP=12"
    exit /b
)
set "GameFilterMode="
for /f "usebackq delims=" %%A in ("!gameFlagFile!") do if not defined GameFilterMode set "GameFilterMode=%%A"
if /i "!GameFilterMode!"=="all" (
    set "GameFilterStatus=enabled (TCP+UDP)"
    set "GameFilter=1024-65535"
    set "GameFilterTCP=1024-65535"
    set "GameFilterUDP=1024-65535"
) else if /i "!GameFilterMode!"=="tcp" (
    set "GameFilterStatus=enabled (TCP)"
    set "GameFilter=1024-65535"
    set "GameFilterTCP=1024-65535"
    set "GameFilterUDP=12"
) else (
    set "GameFilterStatus=enabled (UDP)"
    set "GameFilter=1024-65535"
    set "GameFilterTCP=12"
    set "GameFilterUDP=1024-65535"
)
exit /b

:game_switch
cls
echo.
echo  ������� ������
echo  ============================================================
echo   0. ���������
echo   1. TCP � UDP
echo   2. ������ TCP
echo   3. ������ UDP
echo.
set "GameFilterChoice=0"
set /p "GameFilterChoice=  ����� [0-3, default: 0]: "
if "%GameFilterChoice%"=="" set "GameFilterChoice=0"
if "%GameFilterChoice%"=="0" ( if exist "!gameFlagFile!" del /f /q "!gameFlagFile!" )
if "%GameFilterChoice%"=="1" echo all>"!gameFlagFile!"
if "%GameFilterChoice%"=="2" echo tcp>"!gameFlagFile!"
if "%GameFilterChoice%"=="3" echo udp>"!gameFlagFile!"
call :PrintYellow "������������� ������ ��� ����������."
pause
goto menu


:: ============================================================
:: IPSET SWITCH
:: ============================================================
:ipset_switch_status
chcp 1251 > nul
set "listFile=%~dp0lists\ipset-all.txt"
for /f %%i in ('type "!listFile!" 2^>nul ^| find /c /v ""') do set "lineCount=%%i"
if !lineCount!==0 (
    set "IPsetStatus=any"
) else (
    findstr /R "^203\.0\.113\.113/32$" "!listFile!" >nul
    if !errorlevel!==0 ( set "IPsetStatus=none" ) else ( set "IPsetStatus=loaded" )
)
exit /b

:ipset_switch
cls
set "listFile=%~dp0lists\ipset-all.txt"
set "backupFile=!listFile!.backup"
if "!IPsetStatus!"=="loaded" (
    if not exist "!backupFile!" ( ren "!listFile!" "ipset-all.txt.backup" ) else ( del /f /q "!backupFile!" & ren "!listFile!" "ipset-all.txt.backup" )
    echo 203.0.113.113/32>"!listFile!"
    call :PrintYellow "IPSet: none"
) else if "!IPsetStatus!"=="none" (
    type nul>"!listFile!"
    call :PrintYellow "IPSet: any"
) else if "!IPsetStatus!"=="any" (
    if exist "!backupFile!" ( del /f /q "!listFile!" & ren "!backupFile!" "ipset-all.txt" & call :PrintGreen "IPSet: loaded" ) else (
        call :PrintRed "��������� ����� �� �������. ������� �������� IPSet (����� 12)."
    )
)
pause
goto menu


:: ============================================================
:: �������
:: ============================================================
:load_user_lists
set "LISTS_PATH=%~dp0lists\"
if not exist "!LISTS_PATH!ipset-exclude-user.txt"  echo 203.0.113.113/32>"!LISTS_PATH!ipset-exclude-user.txt"
if not exist "!LISTS_PATH!list-general-user.txt"   echo domain.example.abc>"!LISTS_PATH!list-general-user.txt"
if not exist "!LISTS_PATH!list-exclude-user.txt"   echo domain.example.abc>"!LISTS_PATH!list-exclude-user.txt"
exit /b

:tcp_enable
chcp 1251 > nul
netsh interface tcp show global | findstr /i "timestamps" | findstr /i "enabled" > nul || netsh interface tcp set global timestamps=enabled > nul 2>&1
exit /b

:get_strategy_name
set "CurrentStrategy="
if exist "%~dp0utils\current_strategy.txt" (
    for /f "usebackq delims=" %%A in ("%~dp0utils\current_strategy.txt") do (
        if not defined CurrentStrategy set "CurrentStrategy=%%A"
    )
)
exit /b

:test_service
set "ServiceName=%~1"
set "ServiceStatus="
for /f "tokens=3 delims=: " %%A in ('sc query "%ServiceName%" ^| findstr /i "STATE"') do set "ServiceStatus=%%A"
set "ServiceStatus=%ServiceStatus: =%"
if "!ServiceStatus!"=="RUNNING" ( echo "%ServiceName%": RUNNING. ) else if "!ServiceStatus!"=="STOP_PENDING" ( call :PrintYellow "!ServiceName! STOP_PENDING � �������� ��������" ) else ( echo "%ServiceName%": NOT running. )
exit /b

:PrintGreen
powershell -NoProfile -Command "Write-Host \"%~1\" -ForegroundColor Green"
exit /b

:PrintRed
powershell -NoProfile -Command "Write-Host \"%~1\" -ForegroundColor Red"
exit /b

:PrintYellow
powershell -NoProfile -Command "Write-Host \"%~1\" -ForegroundColor Yellow"
exit /b

:check_command
where %1 >nul 2>&1
if %errorLevel% neq 0 (
    echo [ERROR] %1 �� ������ � PATH
    pause
    exit /b 1
)
exit /b 0

:check_extracted
if not exist "%~dp0bin\" (
    echo ����� bin\ �� �������. ���������� ����� ���������.
    pause
    exit
)
exit /b 0
